<?php

$schema['export_fields']['Condition'] = array (
    'db_field' => 'condition_items'
);

return $schema;

